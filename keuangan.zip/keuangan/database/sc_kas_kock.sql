-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Sep 2020 pada 10.11
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sc_kas_kock`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dana_kock_masuk`
--

CREATE TABLE `dana_kock_masuk` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jumlah` int(50) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dana_kock_masuk`
--

INSERT INTO `dana_kock_masuk` (`id`, `nama`, `jumlah`, `tanggal`) VALUES
(1, 'Wisnu', 10000, '2020-09-16 06:31:11'),
(2, 'Adi', 100000, '2020-09-16 07:08:47');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kas_masuk`
--

CREATE TABLE `kas_masuk` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kas_masuk`
--

INSERT INTO `kas_masuk` (`id`, `nama`, `jumlah`, `tanggal`) VALUES
(14, 'Adi Maulana', 50000, '2020-09-10 07:21:00'),
(16, 'Dexi', 100000, '2020-09-16 04:14:58'),
(17, 'Adi Maulana', 50000, '2020-09-16 06:28:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_bayar`
--

CREATE TABLE `kategori_bayar` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori_bayar`
--

INSERT INTO `kategori_bayar` (`id_kategori`, `nama_kategori`) VALUES
(7, 'Buku'),
(8, 'Ayam');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_dana_kock`
--

CREATE TABLE `kategori_dana_kock` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori_dana_kock`
--

INSERT INTO `kategori_dana_kock` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Biaya Dana Kock');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_kock`
--

CREATE TABLE `kategori_kock` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori_kock`
--

INSERT INTO `kategori_kock` (`id_kategori`, `nama_kategori`) VALUES
(3, 'Sparing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kock_masuk`
--

CREATE TABLE `kock_masuk` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jumlah` int(255) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kock_masuk`
--

INSERT INTO `kock_masuk` (`id`, `nama`, `jumlah`, `tanggal`) VALUES
(2, 'Adi Maulana', 13, '2020-09-15 03:29:18'),
(3, 'Adi Mauana2', 150, '2020-09-15 04:28:07'),
(4, 'Wisnu', 200, '2020-09-16 07:13:58');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_bayar` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_bayar` varchar(200) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_bayar`, `id_kategori`, `nama_bayar`, `jumlah`, `tanggal`) VALUES
(1, 1, 'Bayar Uang kebersihan', 100000, '2018-02-12 13:18:56'),
(7, 1, 'Bayar Pulsa Telepon', 150000, '2018-02-12 13:23:54'),
(9, 2, 'AAA', 200000, '2020-04-10 03:08:20'),
(10, 2, 'ss', 70500, '2020-04-10 03:09:25'),
(11, 6, 'Adi Maulana', 50000, '2020-04-13 09:28:19'),
(12, 7, 'Buku', 80000, '2020-09-10 07:22:24');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran_dana_kock`
--

CREATE TABLE `pembayaran_dana_kock` (
  `id_bayar` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_bayar` varchar(255) NOT NULL,
  `jumlah` int(50) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembayaran_dana_kock`
--

INSERT INTO `pembayaran_dana_kock` (`id_bayar`, `id_kategori`, `nama_bayar`, `jumlah`, `tanggal`) VALUES
(1, 1, 'Wisnu', 50000, '2020-09-16 07:05:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran_kock`
--

CREATE TABLE `pembayaran_kock` (
  `id_bayar` int(11) NOT NULL,
  `id_kategori` int(1) NOT NULL,
  `nama_bayar` varchar(255) NOT NULL,
  `jumlah` int(50) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembayaran_kock`
--

INSERT INTO `pembayaran_kock` (`id_bayar`, `id_kategori`, `nama_bayar`, `jumlah`, `tanggal`) VALUES
(1, 2, 'Kock ', 100, '2020-09-15 03:56:20'),
(2, 3, 'wisnu', 200, '2020-09-16 07:15:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `rule` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `rule`) VALUES
(1, 'Admin 02TPLE011', 'admin', '$2y$10$e54aCJAR2CL9TvD1pdqa8eZcP4cnXblyM6WTj15NdN54fo7kHtUc2', 'Admin'),
(13, 'User 02TPLE011', 'user', '$2y$10$n7uD/WTst3s6OnRHGU37ju1pGAgkQ4uWdEB18Ecnk6x33jWpEQoZG', 'View'),
(16, 'AdiMaulana', 'AdiMaulana', '$2y$10$dltBEI3pTTljbiu3DoH7J.gdtEdlrLHQh8LyJF8ejvfccNO2huZ8u', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dana_kock_masuk`
--
ALTER TABLE `dana_kock_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kas_masuk`
--
ALTER TABLE `kas_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kategori_bayar`
--
ALTER TABLE `kategori_bayar`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `kategori_dana_kock`
--
ALTER TABLE `kategori_dana_kock`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `kategori_kock`
--
ALTER TABLE `kategori_kock`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `kock_masuk`
--
ALTER TABLE `kock_masuk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_bayar`);

--
-- Indeks untuk tabel `pembayaran_dana_kock`
--
ALTER TABLE `pembayaran_dana_kock`
  ADD PRIMARY KEY (`id_bayar`);

--
-- Indeks untuk tabel `pembayaran_kock`
--
ALTER TABLE `pembayaran_kock`
  ADD PRIMARY KEY (`id_bayar`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `dana_kock_masuk`
--
ALTER TABLE `dana_kock_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kas_masuk`
--
ALTER TABLE `kas_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `kategori_bayar`
--
ALTER TABLE `kategori_bayar`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `kategori_dana_kock`
--
ALTER TABLE `kategori_dana_kock`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kategori_kock`
--
ALTER TABLE `kategori_kock`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kock_masuk`
--
ALTER TABLE `kock_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `pembayaran_dana_kock`
--
ALTER TABLE `pembayaran_dana_kock`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pembayaran_kock`
--
ALTER TABLE `pembayaran_kock`
  MODIFY `id_bayar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
