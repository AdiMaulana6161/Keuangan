<?php 
require_once '../../koneksi/conn.php';

session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
}

$id_kategori = $conn->real_escape_string($_GET['id_kategori']);

$sql=$conn->query("DELETE FROM kategori_dana_kock WHERE id_kategori='$id_kategori' ");
if ($sql) {
    echo json_encode(array("status" => TRUE));
}
?>