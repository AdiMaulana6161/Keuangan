<?php 
require_once '../../koneksi/conn.php';

session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
}

$id = $conn->real_escape_string($_GET['id']);

$sql=$conn->query("DELETE FROM kas_masuk WHERE id='$id' ");
if ($sql) {
    echo json_encode(array("status" => TRUE));
}
?>