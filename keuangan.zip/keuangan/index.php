<?php
   session_start();
	include_once "auth/login_prosses.php";
    if($_SESSION['rule'] == "Admin"){
        header("location:dashboardadmin.php");
    } elseif($_SESSION['rule'] == "View"){
        header("location:dashboarduser.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>    
    <title>BARETU | Login</title>
    <!-- Latest compiled and minified CSS -->
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url ?>assets/pixeladmin-lite/plugins/images/cock.jpg">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Optional theme -->
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
</head>

<body>


<div class="login-area login-s2">
    <div class="container">
        <div class="login-box ptb--100">
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" role="form" style="display: block;">
                <div class="login-form-head" style="border-radius:150px;">
                    <h4 style="color:black;">Sign In</h4>
                    <p style="color:black;">Hello there, Sign in and start Baretu</p>
                    	<?php if($errors) {
					                foreach ($errors as $key => $value) {
					                  echo '<div class="alert alert-danger" role="alert">
					                  <i class="glyphicon glyphicon-exclamation-sign"></i>
					                  '.$value.'</div>';                    
					                  }
					                } ?>
                             </div>
                             
                <div class="login-form-body" id="login-form-body">
                    <div class="form-group">
									<label for="username" class="control-label sr-only">Username</label>
									<input type="text" name="username" class="form-control" id="username" placeholder="Username" required>
								</div>
								<div class="form-group">
									<label for="signin-password" class="form-password sr-only">Password</label>
									<input type="password" name="password" class="form-control form-password" id="signin-password" placeholder="Password" required>
								</div>
                    <div class="row mb-4 rmber-area">
                        <div class="col-6">
                            <div class="custom-control custom-checkbox mr-sm-2">
                                <input type="checkbox" class="custom-control-input" id="customControlAutosizing">
                                <label class="custom-control-label" for="customControlAutosizing"><h5 style="color:black;">Remember Me</h5></label>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="login-submit" id="login-submit" class="btn btn-primary btn-sm btn-block" style="widht:50px;">LOGIN</button>
                        
                    <footer>
                            <div class="footer-area">
                                <a href="registeradmin/registeradmin.php">.</a>
                                <p>© Copyright 2020. Adi Maulana <a href="https://github.com/AdiMaulana6161" target="_blank">Github</a>.</p>
                        </div>
                </div>
            </form>
        </div>
    </div>
</div>
    <!-- jQuery -->
    <script src="assets/pixeladmin-lite/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	    
</body>

</html>